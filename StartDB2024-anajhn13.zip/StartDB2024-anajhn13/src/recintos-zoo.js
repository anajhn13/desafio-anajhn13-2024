// src/recintos-zoo.js
class RecintosZoo {
    constructor() {
        this.recintos = [
            { numero: 1, bioma: 'savana', tamanhoTotal: 10, animaisExistentes: [{ especie: 'MACACO', quantidade: 3 }] },
            { numero: 2, bioma: 'floresta', tamanhoTotal: 5, animaisExistentes: [] },
            { numero: 3, bioma: 'savana e rio', tamanhoTotal: 7, animaisExistentes: [{ especie: 'GAZELA', quantidade: 1 }] },
            { numero: 4, bioma: 'rio', tamanhoTotal: 8, animaisExistentes: [] },
            { numero: 5, bioma: 'savana', tamanhoTotal: 9, animaisExistentes: [{ especie: 'LEAO', quantidade: 1 }] }
        ];

        this.animais = {
            LEAO: { tamanho: 3, bioma: ['savana'], carnivoro: true },
            LEOPARDO: { tamanho: 2, bioma: ['savana'], carnivoro: true },
            CROCODILO: { tamanho: 3, bioma: ['rio'], carnivoro: true },
            MACACO: { tamanho: 1, bioma: ['savana', 'floresta'], carnivoro: false },
            GAZELA: { tamanho: 2, bioma: ['savana'], carnivoro: false },
            HIPOPOTAMO: { tamanho: 4, bioma: ['savana', 'rio'], carnivoro: false },
        };
    }

    analisaRecintos(animal, quantidade) {
        // Verificar se o animal é válido
        if (!this.animais[animal]) {
            return { erro: "Animal inválido" };
        }

        // Verificar se a quantidade é válida
        if (quantidade <= 0) {
            return { erro: "Quantidade inválida" };
        }

        const { tamanho, bioma, carnivoro } = this.animais[animal];
        const tamanhoNecessario = quantidade * tamanho;
        let recintosViaveis = [];

        for (const recinto of this.recintos) {
            const espacoOcupado = recinto.animaisExistentes.reduce((acc, { especie, quantidade }) => {
                const espaco = this.animais[especie].tamanho * quantidade;
                return acc + espaco;
            }, 0);
            
            const espacoTotal = recinto.tamanhoTotal;
            const espacoLivre = espacoTotal - espacoOcupado;

            // Verificar bioma adequado
            if (!bioma.includes(recinto.bioma) && !recinto.bioma.includes('savana e rio')) {
                continue;
            }

            // Verificar se há espaço suficiente
            if (espacoLivre < tamanhoNecessario) {
                continue;
            }

            // Verificar se há carnívoros e se o novo animal pode conviver
            const temCarnivoro = recinto.animaisExistentes.some(({ especie }) => this.animais[especie].carnivoro);
            if (temCarnivoro && carnivoro) {
                const mesmaEspecie = recinto.animaisExistentes.every(({ especie }) => especie === animal);
                if (!mesmaEspecie) continue;
            }

            if (!carnivoro && temCarnivoro) continue;

            // Regras especiais para hipopótamos e macacos
            if (animal === 'HIPOPOTAMO' && recinto.bioma !== 'savana e rio') continue;
            if (animal === 'MACACO' && recinto.animaisExistentes.length === 0) continue;

            // Se há mais de uma espécie, precisa de 1 espaço extra
            const temOutraEspecie = recinto.animaisExistentes.length > 0 && recinto.animaisExistentes[0].especie !== animal;
            const espacoNecessarioComExtra = temOutraEspecie ? tamanhoNecessario + 1 : tamanhoNecessario;

            if (espacoLivre >= espacoNecessarioComExtra) {
                recintosViaveis.push(`Recinto ${recinto.numero} (espaço livre: ${espacoLivre - tamanhoNecessario} total: ${espacoTotal})`);
            }
        }

        if (recintosViaveis.length === 0) {
            return { erro: "Não há recinto viável" };
        }

        return { recintosViaveis };
    }
}

export { RecintosZoo as RecintosZoo };
